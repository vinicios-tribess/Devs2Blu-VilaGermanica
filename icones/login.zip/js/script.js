
function meuEscopo () {
    const form = document.querySelector('.form');
    const resultado = document.querySelector('.resultado');
    const Login = [];

      function recebeEventoForm (evento) {
          evento.preventDefault();
          
          const nome = form.querySelector('.nome');
          const sobrenome = form.querySelector('.sobrenome');
          const carteiraSUS = form.querySelector('.carteiraSUS');
          const cpf = form.querySelector('.cpf');

          pessoas.push ({ //adicionar objeto em cada índice do array "LOGIN"
            nome: nome.value,
            sobrenome: sobrenome.value,
            carteiraSUS: carteiraSUS.value,
            cpf: cpf.value
        });
        
        console.log(pessoas); //ver os objetos dentro do array
        resultado.innerHTML += `<p>${nome.value}, ${sobrenome.value}, ${carteiraSUS.value}, ${cpf.value}</p>`

        console.log(nome.value, sobrenome.value, carteiraSUS.value, cpf.value);
    }

    form.addEventListener('submit', recebeEventoForm);

}
meuEscopo();